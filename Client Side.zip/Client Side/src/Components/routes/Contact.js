function Contact() {
    return (  
        <h>Please Contact</h>
    );
}

export default Contact;