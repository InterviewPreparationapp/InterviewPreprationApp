import Navbar from "../Navbar";
function Home() {
    return (  
        <>
        <h1>THis is home</h1>
        <h1>THis is home</h1> <h1>THis is home</h1> <h1>THis is home</h1> <h1>THis is home</h1>

        <h1>THis is home</h1>
        <h1>THis is home</h1>
        <h1>THis is home</h1>
        <h1>THis is home</h1>
        <h1>THis is home</h1>
        <h1>THis is home</h1>
        <h1>THis is home</h1>

        <h1>THis is home</h1>
        
        </>
    );
}

export default Home;