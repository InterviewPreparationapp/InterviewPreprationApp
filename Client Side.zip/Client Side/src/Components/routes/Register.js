import "../css/Login.css";
import { useState } from "react";
function Register() {

    const [FormData,setFormData] = useState({"FName":"","LName":"",
                                             "Email":"","Password":"",
                                             "CnfPassowrd":"","MobileNo":"",
                                             "Address":"","DOB":"",
                                            "Qualification":"","Gender":""
                                            });

   const OnTextChange = (args)=>{
        var inputDataCopy = {...FormData};
        inputDataCopy[args.target.name]=args.target.value
        console.log(inputDataCopy)
        console.log(inputDataCopy)
        setFormData(inputDataCopy)
    }

    const submitReg = ()=>{

    }

    return ( 
        <center>
            <form action="#" method="Post">
            <div className="LoginBox">
                <h3> Register</h3>
                <div>
                  <input type="text" placeholder="Enter Your First Name" value={FormData.FName} name="FName" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Your Last Name" value={FormData.LName} name="LName" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Your Email" value={FormData.Email} name="Email" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Password" value={FormData.Password} name="Password" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Confirm Password" value={FormData.CnfPassowrd} name="CnfPassowrd" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Mobile No." value={FormData.MobileNo} name="MobileNo" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Your Address" value={FormData.Address} name="Address" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="date" placeholder="Enter Your D.O.B.>" value={FormData.DOB} name="DOB" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="text" placeholder="Enter Highest Qualification" value={FormData.Qualification} name="Qualification" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="option" placeholder="Select Gender" value={FormData.Gender} name="Gender" onChange={OnTextChange}></input>
                  <br/><br/>
                </div>
                <div>
                  <input type="Submit" value="Submit" onClick={submitReg}></input>
                  {"  "}{"  "}{"    "}
                  <input type="button" value="Clear"></input>
                  <br/><br/>
                </div>
                
            </div>
            </form>
        </center>
     );
}

export default Register;