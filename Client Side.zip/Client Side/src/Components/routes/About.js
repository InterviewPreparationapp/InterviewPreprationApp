function About() {
    return ( 
        <>
         <h1>THis is about</h1>
        </>
     );
}

export default About;