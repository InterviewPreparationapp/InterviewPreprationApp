import "./css/Footer.css"
function Footer() {
    return (  
        <div className="myfooter">
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
            <h3>This is footer</h3>
        </div>
    );
}

export default Footer;